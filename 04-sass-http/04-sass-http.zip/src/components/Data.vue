<template>
  <div class="data">
    <h2>Información...</h2>

    <h3>
      <span class="cripto">BTC</span>
      -
      <span class="moneda">USD</span>
    </h3>
    <img src="https://www.cryptocompare.com/media/37746238/eth.png" />
    <p>Precio: <strong>$ 300</strong></p>
  </div>
</template>

<script>
export default {};
</script>
