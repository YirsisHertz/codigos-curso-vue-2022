<template>
  <div class="grid">
    <slot></slot>
  </div>
</template>

<script>
export default {};
</script>
